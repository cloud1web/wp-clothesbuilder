<?php

abstract class phpfastcache_extensions {
    function __call($name, $agr) {

    }
}