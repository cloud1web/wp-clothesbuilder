<?php
	$addons = $GLOBALS['addons'];
	$copyItemErrMes = $addons->__('addon_copyitem_errormes');
?>
<script type="text/javascript">
	var copyItemErrMes     = '<?php echo $copyItemErrMes; ?>';
</script>